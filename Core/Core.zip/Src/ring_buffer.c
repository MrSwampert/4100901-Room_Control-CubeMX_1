#include "ring_buffer.h"
/**
 * @brief Inicializa el buffer circular.
 * @param rb Puntero al buffer circular a inicializar.
 * @param buffer Puntero al área de memoria que se usará como buffer.
 * @param capacity Capacidad del buffer circular.
 */
void ring_buffer_init(ring_buffer_t *rb, uint8_t *buffer, uint16_t capacity)
{
    rb->buffer = buffer;
    rb->head = 0;
    rb->tail = 0;
    rb->capacity = capacity;
    rb->is_full = false; // Inicializamos el estado del buffer como no lleno
}

/**
 * @brief Escribe un byte en el buffer circular, descarta los datos viejos si el buffer está lleno.
 * @param rb Puntero al buffer circular.
 * @param data Byte a escribir en el buffer.
 * @return true si se escribió correctamente, false si el buffer está lleno.
 */

bool ring_buffer_write(ring_buffer_t *rb, uint8_t data)
{
    if (rb->is_full) {
        // Si el buffer está lleno, descartamos el dato más antiguo
        rb->tail = (rb->tail + 1) % rb->capacity;
    }
    rb->buffer[rb->head] = data;
    rb->head = (rb->head + 1) % rb->capacity;
    if (rb->head == rb->tail) {
        rb->is_full = true; // Si avanzamos el head y coincide con el tail, el buffer está lleno
    }
    
    return true;
}
/**
 * @brief Lee un byte del buffer circular.
 * @param rb Puntero al buffer circular.
 * @param data Puntero donde se almacenará el byte leído.
 * @return true si se leyó correctamente, false si el buffer está vacío.
 */
bool ring_buffer_read(ring_buffer_t *rb, uint8_t *data)
{
    if (rb->head == rb->tail && !rb->is_full) {
        // El buffer está vacío
        return false;
    }
    *data = rb->buffer[rb->tail];
    rb->tail = (rb->tail + 1) % rb->capacity;
    rb->is_full = false; // Al leer, el buffer ya no está lleno
    return true;
}

/**
 * @brief Cuenta el número de elementos en el buffer circular.
 * @param rb Puntero al buffer circular.
 * @return Número de elementos en el buffer.
 */

uint16_t ring_buffer_count(ring_buffer_t *rb)
{
    if (rb->is_full) {
        return rb->capacity; // Si está lleno, el número de elementos es igual a la capacidad
    }
    if (rb->head >= rb->tail) {
        return rb->head - rb->tail; // Si head está adelante de tail
    } else {
        return rb->capacity - (rb->tail - rb->head); // Si head ha envuelto al tail
    }
}

/**
 * @brief Verifica si el buffer circular está vacío.
 * @param rb Puntero al buffer circular.
 * @return true si el buffer está vacío, false en caso contrario.
 */
bool ring_buffer_is_empty(ring_buffer_t *rb)
{
    return rb->head == rb->tail && !rb->is_full;
}

/**
 * @brief Verifica si el buffer circular está lleno.
 * @param rb Puntero al buffer circular.
 * @return true si el buffer está lleno, false en caso contrario.
 */
bool ring_buffer_is_full(ring_buffer_t *rb)
{
    return rb->is_full;
}

/**
 * @brief Vacía el buffer circular.
 * @param rb Puntero al buffer circular.
 */
void ring_buffer_flush(ring_buffer_t *rb)
{
    rb->head = 0;
    rb->tail = 0;
    rb->is_full = false;
}